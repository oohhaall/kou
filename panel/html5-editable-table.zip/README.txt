A Pen created at CodePen.io. You can find this one at http://codepen.io/ashblue/pen/mCtuA.

 Create and edit an HTML5 table without the use of a library. Uses HTML5's contenteditable and minimal JavaScript.